The navX-Micro project contains the following components:

setup.exe:

- This is the navX MXP-Micro Windows installation program, which installs FTC Libraries and Examples, the navXUI and several Tools.
- FTC Libaries and Examples are installed within the "navx-micro" sub-directory of your current user home directory.  E.g., if your use name is Robot, the Libraries and Examples are installed to C:\Users\Robot\navx-micro.

enclosure: (Directory)

- This directory contains design files for a navX-Micro 3d-printed enclosure.

