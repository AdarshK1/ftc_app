This directory contains the following files:

navx-micro.skp:  Sketchup File for the navX-Micro Circuit Board
navx-micro_base.skp:  Sketchup File for the navX-Micro Enclosure Base (Actual scale)
navx-micro_lid.skp:  Sketchup File for the navX-Micro Enclosure Lid (Actual scale)

In addition, .stl files are Stereo-lithography format files for 3D printing, also at actual (millimeter) scale.